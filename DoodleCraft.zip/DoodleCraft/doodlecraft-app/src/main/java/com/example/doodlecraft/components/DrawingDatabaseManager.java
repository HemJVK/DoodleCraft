package com.example.doodlecraft.components;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

public class DrawingDatabaseManager {

    private static final String URL = "jdbc:postgresql://localhost:5432/your_database";
    private static final String USER = "doodlecraft_user";
    private static final String PASSWORD = "doodle@123";

    public static List<DrawingRecord> getAllDrawings() {
        String sql = "SELECT image_data, name, timestamp FROM drawings";
        List<DrawingRecord> records = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                byte[] imageData = rs.getBytes("image_data");
                BufferedImage image = convertBytesToImage(imageData);
                String name = rs.getString("name");
                Timestamp timestamp = rs.getTimestamp("timestamp");
                records.add(new DrawingRecord(image, name, timestamp));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return records;
    }

    private static BufferedImage convertBytesToImage(byte[] imageData) {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(imageData)) {
            return ImageIO.read(bais);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void saveDrawing(byte[] imageData, String name) {
        String sql = "INSERT INTO drawings (image_data, name, timestamp) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setBytes(1, imageData);
            stmt.setString(2, name);
            stmt.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            stmt.executeUpdate();
            System.out.println("Drawing saved to database successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
