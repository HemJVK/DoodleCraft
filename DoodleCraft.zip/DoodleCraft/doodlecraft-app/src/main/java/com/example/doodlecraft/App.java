package com.example.doodlecraft;

import javax.swing.SwingUtilities;

import com.example.doodlecraft.components.Drawing;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {

        SwingUtilities.invokeLater(Drawing::new);
    }
}
