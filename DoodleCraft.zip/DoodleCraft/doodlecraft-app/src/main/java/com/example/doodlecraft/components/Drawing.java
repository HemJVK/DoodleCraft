package com.example.doodlecraft.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

public class Drawing extends JFrame implements MouseListener, MouseMotionListener {
    private JButton openButton;
    private JButton saveButton;
    private int prevX, prevY;
    private boolean isDragging;
    private boolean isErasing;
    private Canvas canvas;
    private JButton eraserButton;
    private JButton clearButton;
    private JComboBox<String> colorChoice;
    private List<Shape> shapes;
    private JButton modeSwitchButton;
    private boolean isDarkMode;

    private final Color BACKGROUND_COLOR_DARK = Color.BLACK;
    private final Color FOREGROUND_COLOR_DARK = Color.WHITE;
    private final Color BACKGROUND_COLOR_LIGHT = Color.WHITE;
    private final Color FOREGROUND_COLOR_LIGHT = Color.BLACK;

    public Drawing() {
        setTitle("DoodleCraft");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBackground(BACKGROUND_COLOR_LIGHT);
        isDarkMode = false;

        canvas = new Canvas();
        canvas.setBackground(Color.WHITE);
        canvas.addMouseListener(this);
        canvas.addMouseMotionListener(this);

        eraserButton = new JButton("Eraser");
        eraserButton.addActionListener(e -> toggleEraserMode());

        clearButton = new JButton("Clear");
        clearButton.addActionListener(e -> clearCanvas());

        modeSwitchButton = new JButton("Dark Mode");
        modeSwitchButton.addActionListener(e -> toggleMode());

        String[] colors = { "Black", "Red", "Blue", "Green", "Yellow", "Dark Green", "Sky Blue", "Purple", "Orange" };
        colorChoice = new JComboBox<>(colors);
        colorChoice.addActionListener(e -> setColor((String) colorChoice.getSelectedItem()));

        openButton = new JButton("Open Drawings");
        openButton.addActionListener(e -> openDrawingsWindow());

        saveButton = new JButton("Save Drawing");
        saveButton.addActionListener(e -> saveDrawingToDatabase());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(eraserButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(new JLabel("Color:"));
        buttonPanel.add(colorChoice);
        buttonPanel.add(modeSwitchButton);
        buttonPanel.add(openButton);
        buttonPanel.add(saveButton);

        add(buttonPanel, BorderLayout.NORTH);
        add(canvas, BorderLayout.CENTER);

        shapes = new ArrayList<>();

        setVisible(true);
    }

    private void openDrawingsWindow() {
        List<DrawingRecord> drawings = DrawingDatabaseManager.getAllDrawings();
        JFrame galleryFrame = new JFrame("Gallery");
        galleryFrame.setSize(800, 600);
        galleryFrame.setLayout(new GridLayout(0, 3)); // Display in a grid layout

        for (DrawingRecord record : drawings) {
            JLabel imageLabel = new JLabel(new ImageIcon(record.getImage()));
            galleryFrame.add(imageLabel);
        }

        galleryFrame.setVisible(true);
    }

    public BufferedImage captureCanvasImage() {
        BufferedImage image = new BufferedImage(canvas.getWidth(), canvas.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = image.createGraphics();
        canvas.paint(g2d); // Capture the current state of the canvas
        g2d.dispose();
        return image;
    }

    private byte[] convertImageToBytes(BufferedImage image) {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            ImageIO.write(image, "png", baos);
            return baos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void toggleEraserMode() {
        isErasing = !isErasing;
        eraserButton.setText(isErasing ? "Draw" : "Eraser");
    }

    private void clearCanvas() {
        shapes.clear();
        canvas.repaint();
    }

    private void setColor(String colorName) {
        Color color;
        switch (colorName) {
            case "Black":
                color = Color.BLACK;
                break;
            case "Red":
                color = Color.RED;
                break;
            case "Blue":
                color = Color.BLUE;
                break;
            case "Green":
                color = Color.GREEN;
                break;
            case "Yellow":
                color = Color.YELLOW;
                break;
            case "Orange":
                color = Color.ORANGE;
                break;
            case "Dark Green":
                color = new Color(0, 128, 0);
                break;
            case "Sky Blue":
                color = new Color(135, 206, 235);
                break;
            case "Purple":
                color = new Color(128, 0, 128);
                break;
            default:
                color = Color.BLACK;
        }
        canvas.setForeground(color);
        redrawShapes(null);
    }

    void displayDrawing(BufferedImage image) {
        Graphics g = canvas.getGraphics();
        g.drawImage(image, 0, 0, canvas.getWidth(), canvas.getHeight(), null);
        g.dispose();
    }

    private void toggleMode() {
        isDarkMode = !isDarkMode;
        if (isDarkMode) {
            modeSwitchButton.setText("Light Mode");
            getContentPane().setBackground(BACKGROUND_COLOR_DARK);
            canvas.setBackground(BACKGROUND_COLOR_DARK);
            getContentPane().setForeground(FOREGROUND_COLOR_DARK);
        } else {
            modeSwitchButton.setText("Dark Mode");
            getContentPane().setBackground(BACKGROUND_COLOR_LIGHT);
            canvas.setBackground(BACKGROUND_COLOR_LIGHT);
            getContentPane().setForeground(FOREGROUND_COLOR_LIGHT);
        }
        redrawShapes(null);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        redrawShapes(g);
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON1) {
            prevX = e.getX();
            prevY = e.getY();
            isDragging = true;
        } else if (e.getButton() == MouseEvent.BUTTON3) {
            toggleEraserMode();
        }
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (isDragging) {
            if (!isErasing) {
                shapes.add(new Shape(prevX, prevY, e.getX(), e.getY(), canvas.getForeground()));
                redrawShapes(null);
            } else {
                eraseShapesInArea(prevX, prevY, e.getX(), e.getY());
            }
            prevX = e.getX();
            prevY = e.getY();
        }
    }

    private void redrawShapes(Graphics g) {
        if (g == null) {
            g = canvas.getGraphics();
        }
        for (Shape shape : shapes) {
            g.setColor(shape.getColor());
            g.drawLine(shape.getStartX(), shape.getStartY(), shape.getEndX(), shape.getEndY());
        }
    }

    private void eraseShapesInArea(int startX, int startY, int endX, int endY) {
        Rectangle eraseArea = new Rectangle(Math.min(startX, endX), Math.min(startY, endY),
                Math.abs(endX - startX), Math.abs(endY - startY));

        List<Shape> shapesToModify = new ArrayList<>();
        for (Shape shape : shapes) {
            if (eraseArea.intersects(shape.getBounds())) {
                shapesToModify.add(shape);
            }
        }

        for (Shape shape : shapesToModify) {
            shape.setColor(canvas.getBackground());
        }

        redrawShapes(null);
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON1) {
            isDragging = false;
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }

    private void saveDrawingToDatabase() {
        BufferedImage image = captureCanvasImage();
        String name = JOptionPane.showInputDialog(this, "Enter drawing name:");
        if (name == null || name.trim().isEmpty()) {
            name = "Untitled";
        }

        try {
            byte[] imageData = convertImageToBytes(image);
            if (imageData != null) {
                DrawingDatabaseManager.saveDrawing(imageData, name);
                System.out.println("Drawing saved successfully.");
            } else {
                System.err.println("Failed to convert image to bytes.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
