package com.example.doodlecraft.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

public class fillColor extends JFrame {
    private JPanel drawingPanel;
    private Color fillColor = Color.RED; // Default fill color
    private BufferedImage canvas;

    public fillColor() {
        setTitle("DoodleCraft");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Initialize drawing panel
        drawingPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (canvas != null) {
                    g.drawImage(canvas, 0, 0, null);
                }
            }
        };
        drawingPanel.setPreferredSize(new Dimension(600, 400));
        drawingPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                fillShape(e.getPoint());
            }
        });

        getContentPane().add(drawingPanel, BorderLayout.CENTER);

        // Create color chooser button
        JButton colorChooserBtn = new JButton("Choose Fill Color");
        colorChooserBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chooseFillColor();
            }
        });
        getContentPane().add(colorChooserBtn, BorderLayout.SOUTH);

        setVisible(true);
    }

    // Method to choose fill color
    private void chooseFillColor() {
        fillColor = JColorChooser.showDialog(this, "Choose Fill Color", fillColor);
    }

    // Method to perform flood fill algorithm
    private void fillShape(Point start) {
        if (canvas == null) {
            canvas = new BufferedImage(drawingPanel.getWidth(), drawingPanel.getHeight(), BufferedImage.TYPE_INT_ARGB);
        }

        int targetColor = canvas.getRGB(start.x, start.y);
        int fillColorRGB = fillColor.getRGB();

        if (targetColor != fillColorRGB) {
            floodFill(canvas, start.x, start.y, targetColor, fillColorRGB);
            drawingPanel.repaint();
        }
    }

    // Flood fill algorithm
    private void floodFill(BufferedImage image, int x, int y, int targetColor, int fillColor) {
        if (x < 0 || y < 0 || x >= image.getWidth() || y >= image.getHeight()) {
            return;
        }

        if (image.getRGB(x, y) != targetColor) {
            return;
        }

        image.setRGB(x, y, fillColor);

        floodFill(image, x + 1, y, targetColor, fillColor);
        floodFill(image, x - 1, y, targetColor, fillColor);
        floodFill(image, x, y + 1, targetColor, fillColor);
        floodFill(image, x, y - 1, targetColor, fillColor);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new fillColor();
            }
        });
    }
}
