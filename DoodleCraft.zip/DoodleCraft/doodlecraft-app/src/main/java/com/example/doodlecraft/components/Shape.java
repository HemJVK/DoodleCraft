package com.example.doodlecraft.components;

import java.awt.Color;
import java.awt.Rectangle;

public class Shape {
    private int startX;
    private int startY;
    private int endX;
    private int endY;
    private Color color;

    public Shape(int startX, int startY, int endX, int endY, Color color) {
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;
        this.color = color;
    }

    public int getStartX() {
        return startX;
    }

    public int getStartY() {
        return startY;
    }

    public int getEndX() {
        return endX;
    }

    public int getEndY() {
        return endY;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Rectangle getBounds() {
        return new Rectangle(startX, startY, Math.abs(endX - startX), Math.abs(endY - startY));
    }
}