package com.example.doodlecraft.components;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.List;

public class GalleryWindow extends JFrame {
    public GalleryWindow(List<DrawingRecord> records) {
        setTitle("Gallery");
        setSize(800, 600);
        setLayout(new GridLayout(0, 2)); // Adjust layout as needed

        for (DrawingRecord record : records) {
            JPanel panel = new JPanel();
            panel.setLayout(new BorderLayout());

            JLabel nameLabel = new JLabel(record.getName());
            JLabel timestampLabel = new JLabel(record.getTimestamp().toString());

            BufferedImage bufferedImage = record.getImage();
            Image scaledImage = bufferedImage.getScaledInstance(200, 150, Image.SCALE_SMOOTH);
            BufferedImage scaledBufferedImage = new BufferedImage(200, 150, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = scaledBufferedImage.createGraphics();
            g2d.drawImage(scaledImage, 0, 0, null);
            g2d.dispose();

            ImageIcon icon = new ImageIcon(scaledBufferedImage);
            JLabel imageLabel = new JLabel(icon);

            panel.add(nameLabel, BorderLayout.NORTH);
            panel.add(imageLabel, BorderLayout.CENTER);
            panel.add(timestampLabel, BorderLayout.SOUTH);

            add(panel);
        }

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Ensure the window is properly closed
        setVisible(true);
    }
}
