package com.example.doodlecraft.components;

import java.util.List;

public class DrawingService {
    // Method to display all drawings
    public void displayAllDrawings() {
        List<DrawingRecord> drawings = DrawingRecord.getAllDrawingsFromDatabase();
        // Logic to display or process drawings
        for (DrawingRecord record : drawings) {
            // Example of how you might display or process each drawing
            System.out.println("Name: " + record.getName());
            System.out.println("Timestamp: " + record.getTimestamp());
            // Process the image (e.g., display or save it)
        }
    }
}
