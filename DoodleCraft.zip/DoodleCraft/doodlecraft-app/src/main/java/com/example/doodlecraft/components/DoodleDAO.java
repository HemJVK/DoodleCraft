package com.example.doodlecraft.components;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

public class DoodleDAO {
    private Connection connection;

    public DoodleDAO(Connection connection) {
        this.connection = connection;
    }

    public void insertDoodle(String name, byte[] doodleData) throws SQLException {
        String sql = "INSERT INTO doodles (name, creation_date, data) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, name);
            preparedStatement.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            preparedStatement.setBytes(3, doodleData);
            preparedStatement.executeUpdate();
        }
    }
}
