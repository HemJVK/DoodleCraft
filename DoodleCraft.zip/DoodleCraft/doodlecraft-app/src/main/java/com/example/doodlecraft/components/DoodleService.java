package com.example.doodlecraft.components;

import java.sql.SQLException;

public class DoodleService {
    private DoodleDAO doodleDAO;

    public DoodleService(DoodleDAO doodleDAO) {
        this.doodleDAO = doodleDAO;
    }

    public void addNewDoodle(String name, byte[] doodleData) {
        try {
            doodleDAO.insertDoodle(name, doodleData);
            System.out.println("Doodle added to the database.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to add doodle.");
        }
    }
}
