package com.example.doodlecraft.components;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

public class DrawingRecord {
    private BufferedImage image;
    private String name;
    private Timestamp timestamp;

    // Constructor to initialize the fields
    public DrawingRecord(BufferedImage image, String name, Timestamp timestamp) {
        this.image = image;
        this.name = name;
        this.timestamp = timestamp;
    }

    // Getters for the fields
    public BufferedImage getImage() {
        return image;
    }

    public String getName() {
        return name;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    // Static method to retrieve all drawings from the database
    public static List<DrawingRecord> getAllDrawingsFromDatabase() {
        String url = "jdbc:postgresql://localhost:5432/your_database";
        String user = "doodlecraft_user";
        String password = "doodle@123";
        String sql = "SELECT image_data, name, timestamp FROM drawings";

        List<DrawingRecord> records = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(url, user, password);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                byte[] imageData = rs.getBytes("image_data");
                BufferedImage image = convertBytesToImage(imageData);
                String name = rs.getString("name");
                Timestamp timestamp = rs.getTimestamp("timestamp");
                records.add(new DrawingRecord(image, name, timestamp));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return records;
    }

    // Helper method to convert byte array to BufferedImage
    private static BufferedImage convertBytesToImage(byte[] imageData) {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(imageData)) {
            return ImageIO.read(bais);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
